/*******************************************************************************
* File Name: entrada.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_entrada_ALIASES_H) /* Pins entrada_ALIASES_H */
#define CY_PINS_entrada_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define entrada_0			(entrada__0__PC)
#define entrada_0_PS		(entrada__0__PS)
#define entrada_0_PC		(entrada__0__PC)
#define entrada_0_DR		(entrada__0__DR)
#define entrada_0_SHIFT	(entrada__0__SHIFT)
#define entrada_0_INTR	((uint16)((uint16)0x0003u << (entrada__0__SHIFT*2u)))

#define entrada_INTR_ALL	 ((uint16)(entrada_0_INTR))


#endif /* End Pins entrada_ALIASES_H */


/* [] END OF FILE */
